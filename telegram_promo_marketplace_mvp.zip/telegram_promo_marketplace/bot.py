import asyncio
import os
import sqlite3
from datetime import datetime, timezone

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
DB_PATH = os.getenv("DB_PATH", "bot.db")

if not TOKEN:
    raise RuntimeError("Set BOT_TOKEN in .env")
if not ADMIN_IDS:
    raise RuntimeError("Set at least one ADMIN_IDS value in .env")

bot = Bot(TOKEN)
dp = Dispatcher()


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            tg_id INTEGER PRIMARY KEY,
            username TEXT,
            full_name TEXT,
            role TEXT DEFAULT 'none',
            balance INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            target_url TEXT NOT NULL,
            reward INTEGER NOT NULL,
            slots INTEGER NOT NULL,
            status TEXT DEFAULT 'open',
            advertiser_id INTEGER,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            worker_id INTEGER NOT NULL,
            proof TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TEXT NOT NULL,
            UNIQUE(task_id, worker_id)
        );
        CREATE TABLE IF NOT EXISTS ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            reason TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)


def now():
    return datetime.now(timezone.utc).isoformat()


def get_user(tg_user):
    with db() as con:
        con.execute(
            """INSERT INTO users(tg_id, username, full_name, created_at)
               VALUES(?,?,?,?)
               ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username,
               full_name=excluded.full_name""",
            (tg_user.id, tg_user.username or "", tg_user.full_name, now())
        )
        return con.execute("SELECT * FROM users WHERE tg_id=?", (tg_user.id,)).fetchone()


def main_menu(user_id):
    kb = InlineKeyboardBuilder()
    kb.button(text="📣 Заказать рекламное размещение", callback_data="advertise")
    kb.button(text="🧩 Стать исполнителем", callback_data="worker")
    kb.button(text="📋 Доступные задания", callback_data="tasks")
    kb.button(text="💰 Мой баланс", callback_data="balance")
    kb.adjust(1)
    if user_id in ADMIN_IDS:
        kb.button(text="🛠 Админ-панель", callback_data="admin")
        kb.adjust(1)
    return kb.as_markup()


@dp.message(CommandStart())
async def start(message: Message):
    user = get_user(message.from_user)
    await message.answer(
        "Привет! Это бот для организации прозрачных рекламных размещений.\n\n"
        "Здесь можно оставить заявку на рекламу или выполнять задания "
        "(например, разместить рекламный пост в своём канале).\n\n"
        "Оплата за искусственные просмотры, ботов или имитацию активности не поддерживается.",
        reply_markup=main_menu(message.from_user.id)
    )


@dp.callback_query(F.data == "worker")
async def become_worker(call: CallbackQuery):
    get_user(call.from_user)
    with db() as con:
        con.execute("UPDATE users SET role='worker' WHERE tg_id=?", (call.from_user.id,))
    await call.message.answer(
        "Профиль исполнителя создан.\n"
        "Открой «Доступные задания», чтобы посмотреть рекламные задания."
    )
    await call.answer()


@dp.callback_query(F.data == "advertise")
async def advertise(call: CallbackQuery):
    get_user(call.from_user)
    with db() as con:
        con.execute("UPDATE users SET role='advertiser' WHERE tg_id=?", (call.from_user.id,))
    await call.message.answer(
        "Чтобы оставить заявку, отправь одним сообщением:\n\n"
        "Название проекта | описание рекламного размещения | ссылка | "
        "вознаграждение в баллах | количество мест\n\n"
        "Пример:\n"
        "Анонс канала | Опубликовать рекламный пост на 24 часа | "
        "https://example.com | 50 | 3\n\n"
        "Заявка будет отправлена администратору на проверку. "
        "Не указывай задания на искусственную накрутку просмотров."
    )
    await call.answer()


@dp.message(F.text.contains("|"))
async def create_ad_request(message: Message):
    get_user(message.from_user)
    parts = [p.strip() for p in message.text.split("|")]
    if len(parts) != 5:
        return
    title, description, url, reward_s, slots_s = parts
    if not (url.startswith("https://") or url.startswith("http://")):
        await message.answer("Ссылка должна начинаться с http:// или https://.")
        return
    try:
        reward, slots = int(reward_s), int(slots_s)
        if not (1 <= reward <= 100000 and 1 <= slots <= 1000):
            raise ValueError
    except ValueError:
        await message.answer("Вознаграждение и количество мест должны быть положительными числами.")
        return

    with db() as con:
        cur = con.execute(
            """INSERT INTO tasks(title,description,target_url,reward,slots,status,advertiser_id,created_at)
               VALUES(?,?,?,?,?,'review',?,?)""",
            (title, description, url, reward, slots, message.from_user.id, now())
        )
        task_id = cur.lastrowid

    await message.answer(f"Заявка #{task_id} отправлена администратору на проверку.")
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"🆕 Заявка на рекламное задание #{task_id}\n"
                f"Заказчик: {message.from_user.id}\nНазвание: {title}\n"
                f"Описание: {description}\nСсылка: {url}\n"
                f"Награда: {reward} баллов\nМест: {slots}",
                reply_markup=admin_task_review_kb(task_id)
            )
        except Exception:
            pass


def admin_task_review_kb(task_id):
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Опубликовать", callback_data=f"publish:{task_id}")
    kb.button(text="❌ Отклонить", callback_data=f"rejecttask:{task_id}")
    kb.adjust(2)
    return kb.as_markup()


@dp.callback_query(F.data.startswith("publish:"))
async def publish_task(call: CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Нет доступа", show_alert=True)
        return
    task_id = int(call.data.split(":")[1])
    with db() as con:
        cur = con.execute("UPDATE tasks SET status='open' WHERE id=? AND status='review'", (task_id,))
    await call.message.answer("Задание опубликовано." if cur.rowcount else "Заявка уже обработана.")
    await call.answer()


@dp.callback_query(F.data.startswith("rejecttask:"))
async def reject_task(call: CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Нет доступа", show_alert=True)
        return
    task_id = int(call.data.split(":")[1])
    with db() as con:
        con.execute("UPDATE tasks SET status='rejected' WHERE id=? AND status='review'", (task_id,))
    await call.message.answer("Заявка отклонена.")
    await call.answer()


@dp.callback_query(F.data == "tasks")
async def show_tasks(call: CallbackQuery):
    get_user(call.from_user)
    with db() as con:
        rows = con.execute(
            "SELECT * FROM tasks WHERE status='open' AND slots>0 ORDER BY id DESC LIMIT 10"
        ).fetchall()
    if not rows:
        await call.message.answer("Пока нет доступных заданий.")
    for row in rows:
        kb = InlineKeyboardBuilder()
        kb.button(text="📩 Взять задание", callback_data=f"take:{row['id']}")
        await call.message.answer(
            f"Задание #{row['id']}: {row['title']}\n"
            f"{row['description']}\nСсылка: {row['target_url']}\n"
            f"Вознаграждение: {row['reward']} баллов\n"
            f"Свободных мест: {row['slots']}",
            reply_markup=kb.as_markup()
        )
    await call.answer()


@dp.callback_query(F.data.startswith("take:"))
async def take_task(call: CallbackQuery):
    task_id = int(call.data.split(":")[1])
    with db() as con:
        task = con.execute("SELECT * FROM tasks WHERE id=? AND status='open' AND slots>0",
                           (task_id,)).fetchone()
        if not task:
            await call.answer("Задание уже недоступно.", show_alert=True)
            return
        try:
            con.execute(
                "INSERT INTO submissions(task_id,worker_id,proof,created_at) VALUES(?,?,?,?)",
                (task_id, call.from_user.id, "Ожидается подтверждение выполнения", now())
            )
        except sqlite3.IntegrityError:
            await call.answer("Ты уже отправлял заявку на это задание.", show_alert=True)
            return
    await call.message.answer(
        f"Ты взял задание #{task_id}.\n"
        "Выполни рекламное размещение согласно описанию, затем отправь сюда "
        "ссылку на опубликованный пост или другое проверяемое подтверждение."
    )
    await call.answer("Задание принято")


@dp.message(F.text.startswith("http"))
async def submit_proof(message: Message):
    get_user(message.from_user)
    with db() as con:
        row = con.execute(
            """SELECT s.id, s.task_id FROM submissions s
               WHERE s.worker_id=? AND s.status='pending'
               ORDER BY s.id DESC LIMIT 1""",
            (message.from_user.id,)
        ).fetchone()
        if not row:
            return
        con.execute("UPDATE submissions SET proof=? WHERE id=?", (message.text.strip(), row["id"]))
    await message.answer("Подтверждение отправлено на проверку.")
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"🔎 Подтверждение выполнения\nЗадание: #{row['task_id']}\n"
                f"Исполнитель: {message.from_user.id}\nСсылка: {message.text}",
                reply_markup=submission_review_kb(row["id"])
            )
        except Exception:
            pass


def submission_review_kb(submission_id):
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Подтвердить", callback_data=f"approve:{submission_id}")
    kb.button(text="❌ Отклонить", callback_data=f"decline:{submission_id}")
    kb.adjust(2)
    return kb.as_markup()


@dp.callback_query(F.data.startswith("approve:"))
async def approve_submission(call: CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Нет доступа", show_alert=True)
        return
    sub_id = int(call.data.split(":")[1])
    with db() as con:
        sub = con.execute(
            """SELECT s.*, t.reward, t.id AS tid FROM submissions s
               JOIN tasks t ON t.id=s.task_id WHERE s.id=? AND s.status='pending'""",
            (sub_id,)
        ).fetchone()
        if not sub:
            await call.answer("Заявка уже обработана.", show_alert=True)
            return
        con.execute("UPDATE submissions SET status='approved' WHERE id=?", (sub_id,))
        con.execute("UPDATE users SET balance=balance+? WHERE tg_id=?",
                    (sub["reward"], sub["worker_id"]))
        con.execute("INSERT INTO ledger(user_id,amount,reason,created_at) VALUES(?,?,?,?)",
                    (sub["worker_id"], sub["reward"], f"Задание #{sub['tid']}", now()))
        con.execute("UPDATE tasks SET slots=MAX(0,slots-1) WHERE id=?", (sub["tid"],))
        con.execute("UPDATE tasks SET status='closed' WHERE id=? AND slots<=0", (sub["tid"],))
    await bot.send_message(sub["worker_id"], f"Выполнение подтверждено. Начислено {sub['reward']} баллов.")
    await call.message.answer("Выполнение подтверждено, баллы начислены.")
    await call.answer()


@dp.callback_query(F.data.startswith("decline:"))
async def decline_submission(call: CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Нет доступа", show_alert=True)
        return
    sub_id = int(call.data.split(":")[1])
    with db() as con:
        sub = con.execute("SELECT * FROM submissions WHERE id=? AND status='pending'",
                          (sub_id,)).fetchone()
        if not sub:
            await call.answer("Заявка уже обработана.", show_alert=True)
            return
        con.execute("UPDATE submissions SET status='rejected' WHERE id=?", (sub_id,))
    await bot.send_message(sub["worker_id"], "Подтверждение не принято. Обратись к администратору, если считаешь это ошибкой.")
    await call.message.answer("Подтверждение отклонено.")
    await call.answer()


@dp.callback_query(F.data == "balance")
async def balance(call: CallbackQuery):
    with db() as con:
        user = con.execute("SELECT balance FROM users WHERE tg_id=?", (call.from_user.id,)).fetchone()
        entries = con.execute(
            "SELECT amount,reason FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 5",
            (call.from_user.id,)
        ).fetchall()
    amount = user["balance"] if user else 0
    history = "\n".join(f"• +{r['amount']} — {r['reason']}" for r in entries) or "Пока операций нет."
    await call.message.answer(
        f"Баланс: {amount} баллов\n\nПоследние операции:\n{history}\n\n"
        "Баллы внутри бота не являются деньгами и не выводятся автоматически."
    )
    await call.answer()


@dp.callback_query(F.data == "admin")
async def admin_panel(call: CallbackQuery):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Нет доступа", show_alert=True)
        return
    with db() as con:
        review = con.execute("SELECT COUNT(*) n FROM tasks WHERE status='review'").fetchone()["n"]
        pending = con.execute("SELECT COUNT(*) n FROM submissions WHERE status='pending'").fetchone()["n"]
        workers = con.execute("SELECT COUNT(*) n FROM users WHERE role='worker'").fetchone()["n"]
    await call.message.answer(
        f"🛠 Админ-панель\nЗаявок на задания: {review}\n"
        f"Подтверждений на проверке: {pending}\nИсполнителей: {workers}\n\n"
        "Заявки и подтверждения приходят администратору отдельными сообщениями."
    )
    await call.answer()


@dp.message(Command("id"))
async def show_id(message: Message):
    await message.answer(f"Твой Telegram ID: {message.from_user.id}")


async def main():
    init_db()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
